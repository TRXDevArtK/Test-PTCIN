package com.refaldi.testptcin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestPtcinApplicationTests {

	@Test
	void contextLoads() {
	}

}
